# Fluxo App (concepto visual)
Proyecto Capacitor (HTML/CSS/JS). El APK se compila con GitHub Actions desde `fluxo-app.zip`.
