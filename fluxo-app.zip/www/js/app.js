(() => {
const $ = s => document.querySelector(s);
const STEPS = [['Recibido','Tu solicitud llegó al equipo'],['En revisión','Revisamos alcance y requisitos'],['En desarrollo','Estamos construyendo tu solución'],['Pruebas','Validamos que todo fluya'],['Entregado','Listo para usar']];
const P = {
  home:'<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
  box:'<path d="M21 8l-9-5-9 5 9 5z"/><path d="M3 8v8l9 5 9-5V8"/><path d="M12 13v8"/>',
  grid:'<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
  spark:'<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 16v4M17 18h4"/>',
  moon:'<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
  sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  phone:'<rect x="7" y="2" width="10" height="20" rx="3"/><path d="M11 18h2"/>',
  bot:'<rect x="4" y="8" width="16" height="12" rx="4"/><path d="M12 8V4M9 14h.01M15 14h.01"/>',
  globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"/>',
  shield:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  check:'<path d="M5 12l4.5 4.5L19 7"/>', send:'<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>', chev:'<path d="M9 6l6 6-6 6"/>'
};
const ic = (n, s = 22) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${P[n]}</svg>`;
const FLOPPY = '<svg viewBox="0 0 48 48"><path d="M24 6c-8 0-13 5.5-13 13 0 4 1.4 6.4 1.4 9.4 0 2-1.5 3.4-3.4 4.6 3.4 1 6-.2 7-2.4.6 2 2.2 3.6 4.4 3.6 1.4 0 2.6-.8 3.200-2 .6 1.2 1.800 2 3.200 2 2.200 0 3.800-1.600 4.400-3.600 1 2.200 3.600 3.400 7 2.400-1.900-1.200-3.400-2.600-3.400-4.600 0-3 1.400-5.400 1.400-9.400C37 11.500 32 6 24 6z" fill="#3cc7da"/><circle cx="19" cy="20" r="2.600" fill="#fff"/><circle cx="29" cy="20" r="2.600" fill="#fff"/><circle cx="19.500" cy="20.400" r="1.200" fill="#0b2b3d"/><circle cx="29.500" cy="20.400" r="1.200" fill="#0b2b3d"/></svg>';
const SERVICES = [
  {id:'app', n:'App móvil', d:'Tu idea en el bolsillo de tus clientes.', i:'phone', days:21},
  {id:'web', n:'Sitio web', d:'Páginas rápidas, claras y que convierten.', i:'globe', days:14},
  {id:'ia', n:'Automatización con IA', d:'Procesos que trabajan solos, siempre.', i:'bot', days:18},
  {id:'sop', n:'Soporte y mantenimiento', d:'Tu tecnología al día, sin sobresaltos.', i:'shield', days:7}
];
const fmt = d => new Date(Date.now() + d * 864e5).toLocaleDateString('es', {day:'numeric', month:'short'});
const SEED = [
  {id:'FX-1042', n:'App móvil de ventas', i:'phone', step:2, eta:fmt(9)},
  {id:'FX-1038', n:'Automatización de facturas', i:'bot', step:3, eta:fmt(4)},
  {id:'FX-1027', n:'Soporte mensual', i:'shield', step:1, eta:fmt(12)},
  {id:'FX-1031', n:'Sitio web corporativo', i:'globe', step:4, eta:'Entregado'}
];
const store = {get:k => {try{return JSON.parse(localStorage.getItem(k))}catch(e){return null}}, set:(k,v) => {try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
let orders = store.get('fluxo.orders') || SEED, tab = 'home', filter = 'all', typing = false;
let chat = [{b:1, t:'¡Hola! Soy Floppy, la inteligencia de Fluxo. Pregúntame por tus pedidos o pídeme ayuda para solicitar un servicio.'}];
const pct = o => Math.round((o.step + 1) / 5 * 100);
const chip = o => `<span class="chip ${o.step === 4 ? 'ok' : ''}">${STEPS[o.step][0]}</span>`;
const active = () => orders.filter(o => o.step < 4).sort((a, b) => b.step - a.step);

const views = {
  home() {
    const a = active(), m = a[0];
    return `<p class="hi">Hola, Alex</p><h1>Así van tus pedidos hoy</h1>
    ${m ? `<div class="hero"><small>Pedido destacado · ${m.id}</small><h3>${m.n}</h3>
      <div class="bar" style="--w:${pct(m)}%"><b></b></div>
      <div class="row"><span>${STEPS[m.step][0]}</span><span>Entrega estimada: ${m.eta}</span></div>
      <button class="btn" data-a="open" data-v="${m.id}">Ver seguimiento</button></div>`
    : `<div class="hero"><h3>Todo entregado</h3><button class="btn" data-a="tab" data-v="services">Solicitar un servicio</button></div>`}
    <div class="stats"><div><b>${a.length}</b><span>En curso</span></div><div><b>${orders.length - a.length}</b><span>Entregados</span></div><div><b>${orders.length}</b><span>Total</span></div></div>
    <h2>Accesos rápidos</h2>
    <div class="quick"><button data-a="tab" data-v="services"><span class="ib">${ic('grid')}</span>Solicitar servicio</button>
    <button data-a="tab" data-v="floppy"><span class="ib">${ic('spark')}</span>Preguntar a Floppy</button></div>
    <p class="tag">La tecnología nunca deja de avanzar. Nosotros tampoco.</p>`;
  },
  orders() {
    const L = orders.filter(o => filter === 'all' || (filter === 'run' ? o.step < 4 : o.step === 4));
    const fc = (k, t) => `<button class="fc ${filter === k ? 'on' : ''}" data-a="filter" data-v="${k}">${t}</button>`;
    return `<h1>Mis pedidos</h1><div class="chips">${fc('all','Todos')}${fc('run','En curso')}${fc('done','Entregados')}</div>
    <div class="list">${L.map(o => `<button class="ord" data-a="open" data-v="${o.id}"><span class="ib">${ic(o.i)}</span>
      <span class="m"><b>${o.n}</b><small>${o.id} ${chip(o)}</small><div class="bar" style="--w:${pct(o)}%"><b></b></div></span>${ic('chev', 18)}</button>`).join('') || '<p class="tag">No hay pedidos en esta lista.</p>'}</div>`;
  },
  services() {
    return `<h1>¿Qué necesitas construir?</h1><div class="list">${SERVICES.map(s => `<div class="svc"><span class="ib">${ic(s.i)}</span>
      <div><b>${s.n}</b><p>${s.d}</p><button class="btn" data-a="request" data-v="${s.id}">Solicitar</button></div></div>`).join('')}</div>`;
  },
  floppy() {
    const sug = ['Estado de mis pedidos', 'Solicitar un servicio', '¿Qué es Fluxo?'];
    return `<div class="chat"><div class="chead">${FLOPPY}<div><b>Floppy</b><span>Siempre está para ayudarte</span></div></div>
    <div id="msgs"></div><div class="sug">${sug.map(s => `<button class="fc" data-a="ask" data-v="${s}">${s}</button>`).join('')}</div>
    <div class="inp"><input id="q" placeholder="Pregunta, crea y resuelve…" autocomplete="off"><button data-a="send" aria-label="Enviar">${ic('send', 18)}</button></div></div>`;
  }
};
const TABS = [['home','Inicio','home'],['orders','Pedidos','box'],['services','Servicios','grid'],['floppy','Floppy','spark']];

function render() {
  const app = $('#app');
  app.className = tab === 'floppy' ? 'lock' : '';
  app.style.animation = 'none'; app.offsetHeight; app.style.animation = '';
  app.innerHTML = views[tab]();
  $('#tabs').innerHTML = TABS.map(t => `<button class="${tab === t[0] ? 'on' : ''}" data-a="tab" data-v="${t[0]}">${ic(t[2], 22)}${t[1]}</button>`).join('');
  if (tab === 'floppy') drawChat();
}
function drawChat() {
  const box = $('#msgs'); if (!box) return;
  box.innerHTML = chat.map(m => `<div class="msg ${m.b ? '' : 'me'}">${m.t}</div>`).join('') + (typing ? '<div class="msg dots"><i></i><i></i><i></i></div>' : '');
  box.scrollTop = box.scrollHeight;
}
function toast(t) { const e = $('#toast'); e.textContent = t; e.classList.add('on'); setTimeout(() => e.classList.remove('on'), 2200); }
function open(id) {
  const o = orders.find(x => x.id === id); if (!o) return;
  $('#panel').innerHTML = `<div class="grab"></div><div class="ph"><span class="ib">${ic(o.i)}</span><div><small>${o.id}</small><b>${o.n}</b></div></div>
  <div class="meta"><div><small>Estado</small><b>${STEPS[o.step][0]}</b></div><div><small>${o.step === 4 ? 'Resultado' : 'Entrega estimada'}</small><b>${o.eta}</b></div></div>
  <ul class="tl">${STEPS.map((s, i) => {
    const c = i < o.step || o.step === 4 ? 'done' : i === o.step ? 'now' : '';
    return `<li class="${c}"><span class="dt">${c === 'done' ? ic('check', 13) : ''}</span><b>${s[0]}</b><small>${s[1]}</small></li>`;
  }).join('')}</ul><button class="btn" data-a="close" style="width:100%;justify-content:center">Cerrar</button>`;
  $('#sheet').classList.add('open');
}
const close = () => $('#sheet').classList.remove('open');
function go(t) { close(); tab = t; render(); }
function reply(q) {
  const s = q.toLowerCase(), a = active();
  if (/pedido|estado|seguimiento/.test(s)) return a.length ? `Tienes ${a.length} pedido${a.length > 1 ? 's' : ''} en curso. El más avanzado es “${a[0].n}”, ahora en ${STEPS[a[0].step][0].toLowerCase()}. Entrega estimada: ${a[0].eta}.` : 'No tienes pedidos en curso. ¿Quieres solicitar un servicio?';
  if (/servicio|solicitar|app|web/.test(s)) return '¡Claro! Abre la pestaña Servicios y elige lo que necesitas. Tu pedido aparecerá en seguida en Pedidos.';
  if (/fluxo|qui[eé]n/.test(s)) return 'Fluxo crea tecnología que nunca deja de fluir: apps, webs y automatización con IA. Esta app es un concepto visual de lo que vendrá.';
  if (/hola|buenas/.test(s)) return '¡Hola! ¿En qué te ayudo hoy?';
  return 'Esta es una demo del concepto. En la app real podré ayudarte con eso.';
}
function ask(q) {
  q = (q || '').trim(); if (!q || typing) return;
  chat.push({b:0, t:q.replace(/</g, '&lt;')}); typing = true; drawChat();
  const i = $('#q'); if (i) i.value = '';
  setTimeout(() => { typing = false; chat.push({b:1, t:reply(q)}); drawChat(); }, 1100);
}
const actions = {
  tab: go, close, open, filter: v => { filter = v; render(); },
  request(id) {
    const s = SERVICES.find(x => x.id === id), n = 1043 + orders.filter(o => o.id > 'FX-1042').length;
    const o = {id:'FX-' + n, n:s.n, i:s.i, step:0, eta:fmt(s.days)};
    orders.unshift(o); store.set('fluxo.orders', orders); toast('Pedido ' + o.id + ' creado');
    go('orders'); setTimeout(() => open(o.id), 350);
  },
  ask: v => ask(v), send: () => ask($('#q').value), theme: () => setTheme(document.documentElement.dataset.theme !== 'dark')
};
document.addEventListener('click', e => { const t = e.target.closest('[data-a]'); if (t) actions[t.dataset.a](t.dataset.v); });
document.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.id === 'q') ask(e.target.value); });

function setTheme(dark) {
  document.documentElement.dataset.theme = dark ? 'dark' : 'light'; store.set('fluxo.dark', dark);
  $('#themeBtn').innerHTML = ic(dark ? 'sun' : 'moon', 20);
  try {
    const S = window.Capacitor.Plugins.StatusBar;
    S.setStyle({style: dark ? 'DARK' : 'LIGHT'}).catch(() => {});
    S.setBackgroundColor({color: dark ? '#06222e' : '#e8f8fc'}).catch(() => {});
  } catch (e) {}
}
function bubbles(el, n) {
  for (let k = 0; k < n; k++) {
    const b = document.createElement('i'), s = 12 + Math.random() * 46;
    b.style.cssText = `width:${s}px;height:${s}px;left:${Math.random() * 100}%;--dx:${(Math.random() - .5) * 90}px;animation-duration:${9 + Math.random() * 12}s;animation-delay:-${Math.random() * 14}s`;
    el.appendChild(b);
  }
}
bubbles($('#water'), 10); bubbles($('#water2'), 12);
setTheme(!!store.get('fluxo.dark')); render();
setTimeout(() => { $('#splash').classList.add('out'); setTimeout(() => $('#splash').remove(), 800); }, 2900);
try {
  const A = window.Capacitor.Plugins.App;
  A.addListener('backButton', () => {
    if ($('#sheet').classList.contains('open')) close(); else if (tab !== 'home') go('home'); else A.exitApp();
  });
} catch (e) {}
})();
