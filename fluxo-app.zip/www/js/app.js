(() => {
const $ = s => document.querySelector(s);
const STEPS = [['Recibido','Registramos tu equipo'],['Diagnóstico','Revisamos qué le pasa'],['En reparación','Nuestro técnico lo está arreglando'],['Pruebas','Verificamos que todo funcione'],['Listo','Listo para recoger o recibir']];
const P = {
  home:'<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
  wrench:'<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
  laptop:'<rect x="4" y="5" width="16" height="11" rx="2"/><path d="M2 20h20"/>',
  user:'<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',
  bell:'<path d="M6 8a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8"/><path d="M10 20a2 2 0 0 0 4 0"/>',
  plus:'<path d="M12 5v14M5 12h14"/>',
  dollar:'<path d="M12 2v20"/><path d="M17 7c-1-1.800-3-2.500-5-2.500-2.800 0-4.800 1.300-4.800 3.500 0 4.800 10 2.300 10 7 0 2.200-2 3.500-5.200 3.500-2.200 0-4.200-.8-5.200-2.500"/>',
  chat:'<path d="M21 12a8 8 0 0 1-11.500 7.200L4 20l1-4.500A8 8 0 1 1 21 12z"/>',
  spark:'<path d="M12 3l1.800 5.200L19 10l-5.200 1.800L12 17l-1.800-5.200L5 10l5.200-1.800z"/><path d="M19 16v4M17 18h4"/>',
  shield:'<path d="M12 3l8 3v6c0 5-3.500 8-8 9-4.500-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
  check:'<path d="M5 12l4.500 4.500L19 7"/>', send:'<path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/>', chev:'<path d="M9 6l6 6-6 6"/>'
};
const ic = (n, s = 22) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">${P[n]}</svg>`;
const FLOPPY = '<svg viewBox="0 0 48 48"><path d="M24 6c-8 0-13 5.500-13 13 0 4 1.400 6.400 1.400 9.400 0 2-1.500 3.400-3.400 4.600 3.400 1 6-.2 7-2.400.6 2 2.200 3.600 4.400 3.600 1.400 0 2.600-.8 3.200-2 .6 1.200 1.800 2 3.200 2 2.200 0 3.800-1.600 4.400-3.600 1 2.200 3.600 3.400 7 2.400-1.900-1.200-3.400-2.600-3.400-4.600 0-3 1.400-5.400 1.400-9.400C37 11.500 32 6 24 6z" fill="#2ec0e6"/><circle cx="19" cy="20" r="2.600" fill="#fff"/><circle cx="29" cy="20" r="2.600" fill="#fff"/><circle cx="19.500" cy="20.400" r="1.200" fill="#0a2a4d"/><circle cx="29.500" cy="20.400" r="1.200" fill="#0a2a4d"/></svg>';
const SERVICES = [
  {id:'cel', e:'📱', n:'Celulares', d:'Pantallas, baterías y carga', days:3},
  {id:'pc', e:'💻', n:'Laptops y PC', d:'Diagnóstico y cambio de piezas', days:5},
  {id:'net', e:'📶', n:'Redes y WiFi', d:'Instalación y señal', days:2},
  {id:'imp', e:'🖨️', n:'Impresoras', d:'Atascos, tinta y limpieza', days:4},
  {id:'con', e:'🎮', n:'Consolas', d:'Limpieza, HDMI y sobrecalentamiento', days:5}
];
const fmt = d => new Date(Date.now() + d * 864e5).toLocaleDateString('es', {day:'numeric', month:'short'});
const SEED = [
  {id:'FX-2041', e:'📱', t:'iPhone 13', q:'Cambio de pantalla', step:2, eta:fmt(2)},
  {id:'FX-2038', e:'💻', t:'Laptop Lenovo', q:'Diagnóstico y limpieza', step:1, eta:fmt(5)},
  {id:'FX-2030', e:'📶', t:'Router WiFi 6', q:'Instalación y señal', step:3, eta:fmt(1)},
  {id:'FX-2022', e:'📱', t:'Samsung A54', q:'Cambio de batería', step:4, eta:'Entregado'}
];
const store = {get:k => {try{return JSON.parse(localStorage.getItem(k))}catch(e){return null}}, set:(k,v) => {try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
let orders = store.get('fluxo.v2') || SEED, tab = 'home', filter = 'all', typing = false, draft = {};
let chat = [{b:1, t:'¡Hola! Soy Floppy. Pregúntame por el estado de tus equipos o pídeme ayuda para solicitar un servicio.'}];
const pct = o => (o.step + 1) * 20;
const chip = o => `<span class="chip ${o.step === 4 ? 'ok' : ''}">${STEPS[o.step][0]}</span>`;
const active = () => orders.filter(o => o.step < 4).sort((a, b) => b.step - a.step);
const esc = s => s.replace(/[<>&]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;'}[c]));
const ring = p => `<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="27" fill="none" stroke="currentColor" stroke-opacity=".25" stroke-width="6"/><circle cx="32" cy="32" r="27" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round" stroke-dasharray="169.6" stroke-dashoffset="${169.6 * (1 - p / 100)}" transform="rotate(-90 32 32)"/></svg><span>${p}%</span>`;
const row = o => `<div class="ord" data-a="open" data-v="${o.id}"><span class="em">${o.e}</span><div class="m"><b>${o.t}</b><small>${o.q}</small><div class="bar" style="--w:${pct(o)}%"><i></i></div></div><div class="rt">${chip(o)}<small>${o.id}</small></div></div>`;

const views = {
  home() {
    const a = active(), m = a[0];
    const hero = m ? `<div class="hero" data-a="open" data-v="${m.id}"><div class="hm"><small>Reparación en curso</small><h3>${m.t}</h3><p>${STEPS[m.step][0]} · paso ${m.step + 1} de 5</p></div><div class="rg">${ring(pct(m))}</div><img class="wm" src="assets/logo.png" alt=""></div>`
      : `<div class="hero" data-a="req"><div class="hm"><small>Sin reparaciones en curso</small><h3>Solicita tu primer servicio</h3><p>Aquí verás cada paso</p></div><img class="wm" src="assets/logo.png" alt=""></div>`;
    const qa = [['plus','Solicitar','req',''],['dollar','Cotizar','quote',''],['laptop','Equipos','tab','orders'],['chat','Soporte','tab','floppy']];
    return `<div class="hdr"><img src="assets/logo.png" alt=""><div><h1>Hola</h1><p>¿Qué equipo revisamos hoy?</p></div><button class="bell" data-a="bell" aria-label="Avisos">${ic('bell', 24)}${a.length ? '<i></i>' : ''}</button></div>
    <button class="ask" data-a="tab" data-v="floppy">${ic('spark', 24)}<span>Pregúntale a Floppy…</span></button>${hero}
    <div class="qa">${qa.map(q => `<button data-a="${q[2]}" data-v="${q[3]}"><span>${ic(q[0], 28)}</span>${q[1]}</button>`).join('')}</div>
    <div class="sh"><h2>Servicios</h2><button data-a="tab" data-v="services">Ver todos</button></div>
    <div class="hs">${SERVICES.map(s => `<button class="sv" data-a="req" data-v="${s.id}"><div class="em">${s.e}</div><b>${s.n}</b><small>${s.d}</small></button>`).join('')}</div>
    <div class="sh"><h2>Mis equipos</h2><button data-a="tab" data-v="orders">Ver todos</button></div>
    <div class="list">${orders.slice(0, 2).map(row).join('')}</div>`;
  },
  services() {
    return `<h1 class="ttl">Servicios</h1><p class="sub">Elige qué necesitas y nosotros nos encargamos</p>
    <div class="list">${SERVICES.map(s => `<div class="svl"><span class="em">${s.e}</span><div><b>${s.n}</b><p>${s.d}</p><button class="btn" data-a="req" data-v="${s.id}">Solicitar</button></div></div>`).join('')}</div>`;
  },
  orders() {
    const L = orders.filter(o => filter === 'all' || (filter === 'run' ? o.step < 4 : o.step === 4));
    const fc = (k, t) => `<button class="fc ${filter === k ? 'on' : ''}" data-a="filter" data-v="${k}">${t}</button>`;
    return `<h1 class="ttl">Mis equipos</h1><p class="sub">Sigue cada reparación paso a paso</p>
    <div class="chips">${fc('all', 'Todos')}${fc('run', 'En curso')}${fc('done', 'Listos')}</div>
    <div class="list">${L.map(row).join('') || '<p class="sub">No hay equipos en esta lista.</p>'}</div>`;
  },
  profile() {
    const a = active().length;
    return `<h1 class="ttl">Perfil</h1><p class="sub">Tu espacio personal</p>
    <div class="pf"><div class="av">A</div><div><b>Alex Rivera</b><small>alex@fluxo.app</small></div></div>
    <div class="stats"><div><b>${orders.length}</b><span>Equipos</span></div><div><b>${a}</b><span>En curso</span></div><div><b>${orders.length - a}</b><span>Listos</span></div></div>
    ${[['user','Mis datos'],['bell','Notificaciones'],['shield','Seguridad'],['chat','Ayuda y soporte']].map(r => `<button class="row">${ic(r[0])}<span>${r[1]}</span>${ic('chev', 18)}</button>`).join('')}
    <p class="ver">Fluxo · concepto visual v0.2</p>`;
  },
  floppy() {
    const sug = ['Estado de mis equipos', 'Solicitar un servicio', '¿Qué es Fluxo?'];
    return `<div class="chat"><div class="chead">${FLOPPY}<div><b>Floppy</b><span>Siempre está para ayudarte</span></div></div>
    <div id="msgs"></div><div class="sug">${sug.map(s => `<button class="fc" data-a="ask" data-v="${s}">${s}</button>`).join('')}</div>
    <div class="inp"><input id="q" placeholder="Pregunta, crea y resuelve…" autocomplete="off"><button data-a="send" aria-label="Enviar">${ic('send', 18)}</button></div></div>`;
  }
};
const TABS = [['home','Inicio','home'], ['services','Servicios','wrench'], 0, ['orders','Equipos','laptop'], ['profile','Perfil','user']];
function render() {
  const app = $('#app');
  app.className = tab === 'floppy' ? 'lock' : '';
  app.style.animation = 'none'; app.offsetHeight; app.style.animation = '';
  app.innerHTML = views[tab]();
  $('#tabs').innerHTML = TABS.map(t => t ? `<button class="${tab === t[0] ? 'on' : ''}" data-a="tab" data-v="${t[0]}">${ic(t[2], 25)}${t[1]}${tab === t[0] ? '<u></u>' : ''}</button>`
    : `<button class="fab ${tab === 'floppy' ? 'on' : ''}" data-a="tab" data-v="floppy" aria-label="Floppy">${ic('spark', 32)}</button>`).join('');
  if (tab === 'floppy') drawChat();
}
function drawChat() {
  const box = $('#msgs'); if (!box) return;
  box.innerHTML = chat.map(m => `<div class="msg ${m.b ? '' : 'me'}">${m.t}</div>`).join('') + (typing ? '<div class="msg dots"><i></i><i></i><i></i></div>' : '');
  box.scrollTop = box.scrollHeight;
}
function toast(t) { const e = $('#toast'); e.textContent = t; e.classList.add('on'); setTimeout(() => e.classList.remove('on'), 2400); }
const sheet = h => { $('#panel').innerHTML = '<div class="grab"></div>' + h; $('#panel').scrollTop = 0; $('#sheet').classList.add('open'); };
const close = () => $('#sheet').classList.remove('open');
function open(id) {
  const o = orders.find(x => x.id === id); if (!o) return;
  sheet(`<div class="ph"><span class="em">${o.e}</span><div><small>${o.id}</small><b>${o.t}</b><small>${o.q}</small></div><div class="rg">${ring(pct(o))}</div></div>
  <div class="meta"><div><small>Estado</small><b>${STEPS[o.step][0]}</b></div><div><small>${o.step === 4 ? 'Resultado' : 'Entrega estimada'}</small><b>${o.eta}</b></div></div>
  <ul class="tl">${STEPS.map((s, i) => {
    const c = i < o.step || o.step === 4 ? 'done' : i === o.step ? 'now' : '';
    return `<li class="${c}"><span class="dt">${c === 'done' ? ic('check', 14) : ''}</span><b>${s[0]}</b><small>${s[1]}</small></li>`;
  }).join('')}</ul><button class="btn wide" data-a="close">Cerrar</button>`);
}
function req(mode, id) {
  draft = {mode, svc: id || SERVICES[0].id}; const q = mode === 'quote';
  sheet(`<h2 class="ttl" style="font-size:25px">${q ? 'Pedir cotización' : 'Solicitar servicio'}</h2><p class="sub">${q ? 'Te respondemos en menos de 1 hora' : '¿Qué equipo necesita ayuda?'}</p>
  <div class="chips wrap">${SERVICES.map(s => `<button class="fc ${s.id === draft.svc ? 'on' : ''}" data-a="pick" data-v="${s.id}">${s.e} ${s.n}</button>`).join('')}</div>
  <textarea id="prob" rows="3" placeholder="Cuéntanos qué le pasa (opcional)"></textarea>
  <button class="btn wide" data-a="submit">${q ? 'Pedir cotización' : 'Enviar solicitud'}</button>`);
}
function bell() {
  const L = orders.slice(0, 5);
  sheet(`<h2 class="ttl" style="font-size:25px">Avisos</h2><p class="sub">Novedades de tus equipos</p>${L.map(o => `<div class="nt"><span class="em">${o.e}</span><div><b>${o.t}</b><br><small>${o.step === 4 ? 'Listo para recoger o recibir' : 'Ahora en ' + STEPS[o.step][0].toLowerCase()} · ${o.id}</small></div></div>`).join('')}`);
}
function submit() {
  const s = SERVICES.find(x => x.id === draft.svc), q = esc(($('#prob').value || '').trim().slice(0, 60));
  if (draft.mode === 'quote') { close(); toast('Cotización enviada. Te respondemos pronto'); return; }
  const n = Math.max(...orders.map(o => +o.id.slice(3))) + 1;
  const o = {id:'FX-' + n, e:s.e, t:s.n, q:q || 'Por diagnosticar', step:0, eta:fmt(s.days)};
  orders.unshift(o); store.set('fluxo.v2', orders); toast('Solicitud ' + o.id + ' creada');
  close(); filter = 'all'; tab = 'orders'; render(); setTimeout(() => open(o.id), 450);
}
function go(t) { close(); tab = t; render(); }
function reply(q) {
  const s = q.toLowerCase(), a = active();
  if (/equipo|pedido|estado|reparaci/.test(s)) return a.length ? `Tienes ${a.length} equipo${a.length > 1 ? 's' : ''} en curso. El más avanzado es ${a[0].t}, ahora en ${STEPS[a[0].step][0].toLowerCase()}. Entrega estimada: ${a[0].eta}.` : 'No tienes equipos en curso. ¿Solicitamos un servicio?';
  if (/servicio|solicitar|cotiz/.test(s)) return '¡Claro! Toca “Solicitar” en el inicio o entra a Servicios y elige lo que necesitas. Verás el avance en Equipos.';
  if (/fluxo|qui[eé]n/.test(s)) return 'Fluxo es tecnología que nunca deja de fluir: reparación, redes y asistencia con IA. Esta app es un concepto visual de lo que vendrá.';
  if (/hola|buenas/.test(s)) return '¡Hola! ¿En qué te ayudo hoy?';
  return 'Esta es una demo del concepto. En la app real podré ayudarte con eso.';
}
function ask(q) {
  q = (q || '').trim(); if (!q || typing) return;
  chat.push({b:0, t:esc(q)}); typing = true; drawChat();
  const i = $('#q'); if (i) i.value = '';
  setTimeout(() => { typing = false; chat.push({b:1, t:reply(q)}); drawChat(); }, 1100);
}
const actions = {
  tab: go, close, open, bell, submit, ask: v => ask(v), send: () => ask($('#q').value),
  filter: v => { filter = v; render(); }, req: v => req('req', v), quote: () => req('quote'),
  pick: v => { draft.svc = v; document.querySelectorAll('#panel .fc').forEach(b => b.classList.toggle('on', b.dataset.v === v)); }
};
document.addEventListener('click', e => { const t = e.target.closest('[data-a]'); if (t) actions[t.dataset.a](t.dataset.v); });
document.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.id === 'q') ask(e.target.value); });
function bubbles(el, n) {
  for (let k = 0; k < n; k++) {
    const b = document.createElement('i'), s = 14 + Math.random() * 50;
    b.style.cssText = `width:${s}px;height:${s}px;left:${Math.random() * 100}%;--dx:${(Math.random() - .5) * 90}px;animation-duration:${10 + Math.random() * 12}s;animation-delay:-${Math.random() * 16}s`;
    el.appendChild(b);
  }
}
bubbles($('#water'), 9); bubbles($('#water2'), 12); render();
try {
  const S = window.Capacitor.Plugins.StatusBar;
  S.setStyle({style: 'LIGHT'}).catch(() => {}); S.setBackgroundColor({color: '#e8f8fc'}).catch(() => {});
} catch (e) {}
setTimeout(() => { $('#splash').classList.add('out'); setTimeout(() => $('#splash').remove(), 800); }, 2900);
try {
  const A = window.Capacitor.Plugins.App;
  A.addListener('backButton', () => {
    if ($('#sheet').classList.contains('open')) close(); else if (tab !== 'home') go('home'); else A.exitApp();
  });
} catch (e) {}
})();
